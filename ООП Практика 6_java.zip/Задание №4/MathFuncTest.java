public class MathFuncTest {
    public static void main(String[]a){MathFunc m=new MathFunc();System.out.println(m.pow(2,5));System.out.println(m.modulus(new Complex(3,4)));}
}