public interface MathCalculable {
    double PI=Math.PI; double pow(double base,int exp); double modulus(Complex c);
}