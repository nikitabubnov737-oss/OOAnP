public class MergeSortStudents {

    public static Student[] mergeSort(Student[] arr) {
        if (arr.length <= 1) return arr;

        int mid = arr.length / 2;

        Student[] left = new Student[mid];
        Student[] right = new Student[arr.length - mid];

        System.arraycopy(arr, 0, left, 0, mid);
        System.arraycopy(arr, mid, right, 0, arr.length - mid);

        left = mergeSort(left);
        right = mergeSort(right);

        return merge(left, right);
    }

    private static Student[] merge(Student[] a, Student[] b) {
        Student[] result = new Student[a.length + b.length];

        int i = 0, j = 0, k = 0;

        while (i < a.length && j < b.length) {
            if (a[i].compareTo(b[j]) <= 0)
                result[k++] = a[i++];
            else
                result[k++] = b[j++];
        }

        while (i < a.length) result[k++] = a[i++];
        while (j < b.length) result[k++] = b[j++];

        return result;
    }
}
