import javax.swing.*;
import java.awt.*;

public class ImageViewer extends JFrame {
    public ImageViewer(String path) {
        super("Image Viewer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        JLabel label = new JLabel(new ImageIcon(path));
        label.setHorizontalAlignment(JLabel.CENTER);
        add(label, BorderLayout.CENTER);
        setVisible(true);
    }

    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Укажите путь к изображению в аргументах командной строки.");
            return;
        }
        new ImageViewer(args[0]);
    }
}