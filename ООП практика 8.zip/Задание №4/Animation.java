import javax.swing.*;
import java.awt.*;

public class Animation extends JFrame {
    private JLabel label;
    private ImageIcon[] frames;
    private int index = 0;

    public Animation() {
        super("Animation Example");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        label = new JLabel();
        label.setHorizontalAlignment(JLabel.CENTER);
        add(label, BorderLayout.CENTER);

        frames = new ImageIcon[3];
        for (int i = 0; i < frames.length; i++) {
            frames[i] = new ImageIcon("frame" + (i + 1) + ".png");
        }

        Timer timer = new Timer(300, e -> {
            label.setIcon(frames[index]);
            index = (index + 1) % frames.length;
        });
        timer.start();
        setVisible(true);
    }

    public static void main(String[] args) {
        new Animation();
    }
}