import javax.swing.*;
import java.awt.*;
import java.util.*;

public class RandomShapes extends JPanel {
    private Shape[] shapes;

    public RandomShapes() {
        Random rand = new Random();
        shapes = new Shape[20];
        for (int i = 0; i < shapes.length; i++) {
            Color c = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
            int x = rand.nextInt(400);
            int y = rand.nextInt(300);
            if (rand.nextBoolean())
                shapes[i] = new Circle(c, x, y, 30 + rand.nextInt(50));
            else
                shapes[i] = new Rectangle(c, x, y, 40 + rand.nextInt(50), 30 + rand.nextInt(40));
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Shape s : shapes)
            s.draw(g);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Random Shapes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.add(new RandomShapes());
        frame.setVisible(true);
    }
}